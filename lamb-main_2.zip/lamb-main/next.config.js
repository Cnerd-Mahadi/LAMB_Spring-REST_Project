/** @type {import('next').NextConfig} */
module.exports = {
  reactStrictMode: true,
  // async rewrites() {
  //   return [
  //     {
  //       source: 'https://lamb-backend.herokuapp.com/backend/:path*',
  //       destination: 'http://localhost:3000/:path*',
  //     },
  //   ]
  // },
}
